        
    </main> <!-- /container -->

    <hr>

	<script src="<?php echo BASEURL; ?>/js/main.js"></script>
	
</body>

</html>