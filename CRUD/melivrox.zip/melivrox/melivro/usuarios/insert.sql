INSERT INTO usuario(cidade, endereco, telefone, sexo, cpf) 
VALUES ('Pelotas', 'Goncalves Chaves 1003', '32821525', 'M', '01921233122'),
('Pelotas', 'Goncalves Chaves 1003', '32221525', 'F', '03247223254');